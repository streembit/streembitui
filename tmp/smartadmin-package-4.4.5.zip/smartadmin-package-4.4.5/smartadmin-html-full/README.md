# README #

This README would normally document whatever steps are necessary to get your application up and running.

### What is this repository for? ###

* NextGen WebApp base (not full) application. Created with Bootstrap v4, JQ3.0, SASS and all the latest hibbi-jibbi
* Version 0.0.1
* [Learn Markdown](https://bitbucket.org/tutorials/markdowndemo)

### How do I get set up? ###

* The template takes the strengh of Handlebar templating scheme combined with gulp sass automated tasks.
+ To Build do the following:
  * install nodeJS any version from 5.0 to 6.9.2 (https://nodejs.org/en/)
  * open "node.js command prompt"
  * go to {projects folder with cd/ - > cd/[project folder]
  * npm install gulp
  * npm install
  * gulp build (builds all assets to ./dist and watches for all changes in ./src)
* Dependencies
* Deployment instructions

### Contribution guidelines ###

* Writing tests
* Code review
* Other guidelines

### Who do I talk to? ###

* Sunny A. (@myplaneticket) 