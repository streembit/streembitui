'use strict';

var requireDir = require('require-dir');

requireDir('./build', {recurse: true});