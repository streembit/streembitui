// lower.js
module.exports = function (text) {
    return String(text).toLowerCase();
};