"use strict";
$.fn.markdown.defaults.iconlibrary = 'fal';
$.fn.markdown.defaults.buttons[0][0]['data'][2]['icon']['fa'] = 'fal fa-heading';
$.fn.markdown.defaults.buttons[0][1]['data'][1]['icon']['fa'] = 'fal fa-image';
$.fn.markdown.defaults.buttons[0][2]['data'][1]['icon']['fa'] = 'fal fa-list-ol';
